
# NET-D1-102 - Process model comparison

## Windows track (IIS + ASP.NET Core Module v2)

| Mode | Process | PID | Parent PID | Memory (MB) | Who answered /whoami |
|------|---------|-----|------------|-------------|----------------------|
| In-Process | Not tested | N/A | N/A | N/A | Not tested |
| Out-of-Process | w3wp.exe | 5296 | 6792 | 15.1 | (proxy only) |
| Out-of-Process | dotnet.exe | 1180 | 5296 | 48.5 | dotnet |

## In one or two sentences: what is the practical difference between the two models?

In-Process hosting runs the application inside the IIS worker process (w3wp.exe). Out-of-Process hosting runs the application in a separate dotnet.exe process, while IIS forwards requests to that process.
