# NET-D1-103 - Evidence

## 1. The original failure (paste the Application Event Log entry on Windows, or the `journalctl -u invoicesync` lines on Ubuntu)

```
TimeCreated: 14-11-2026 03:46:10 ProviderName: InvoiceSync EventId: 11 Category: Microsoft.Extensions.Hosting.Internal.Host
Hosting failed to start.
Exception: Microsoft.Extensions.Options.OptionsValidationException: DataAnnotation validation failed for 'ErpSettings' members: 'ConnectionString' with the error:
'ConnectionString for Production ERP is required and must not be empty!'
The exception occurred during SyncWorker initialization in SyncWorker.cs, line 14.

```

## 2. Why did the service believe it was in "Production"? (two or three sentences, your own words)

The service believed it was running in Production because the configured environment variable was 
ASPNETCORE_ENVIRONMENT=Staging. However, InvoiceSyncService uses the .NET Generic Host with Host.CreateApplicationBuilder(), 
which reads DOTNET_ENVIRONMENT to determine its environment. Since DOTNET_ENVIRONMENT was missing, 
the application defaulted to Production and loaded appsettings.json instead of appsettings.Staging.json. As a result, the ERP ConnectionString was empty.

```

## 3. The exact command(s) you used to inject DOTNET_ENVIRONMENT=Staging

```
Set-ItemProperty `
-Path "HKLM:\SYSTEM\CurrentControlSet\Services\InvoiceSyncService" `
-Name Environment `
-Value "DOTNET_ENVIRONMENT=Staging"
Verification:


Get-ItemProperty `
"HKLM:\SYSTEM\CurrentControlSet\Services\InvoiceSyncService" `
-Name Environment

```

## 4. Heartbeat proof (paste 2-3 lines from invoice_sync.log that show "Environment: Staging")

```
2026-11-14 03:53:29 -08:00 [HEARTBEAT] Environment: Staging - Synchronized 0 pending invoices (ledger STAGING-LEDGER-SANDBOX)
2026-11-14 03:53:59 -08:00 [HEARTBEAT] Environment: Staging - Synchronized 0 pending invoices (ledger STAGING-LEDGER-SANDBOX)
2026-11-14 03:54:29 -08:00 [HEARTBEAT] Environment: Staging - Synchronized 0 pending invoices (ledger STAGING-LEDGER-SANDBOX)
```

